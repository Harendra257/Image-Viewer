export const constants = {
  userMediaUrl:"https://graph.instagram.com",
  userInfoUrl:"https://graph.instagram.com/me/media?fields=id,caption&access_token"
}
